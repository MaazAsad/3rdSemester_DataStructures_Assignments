GAME OF LIFE 
A simulator devised by the British mathematician John Horton Conway in 1970.
Rules of the game:
The universe of the Game of life is an infinite two-dimensional plane of square cells
each of which is in one of two possible states, dead or alive.
Cells interact with their eight neighbours (horizontally, vertically, or diagonally adjacent).
At each iteration, the following changes occur:
1. Any live cell with fewer than two live neighbours dies by under-population.
2. Any live cell with two or three live neighbours lives on to the next generation.
3. Any live cell with more than three live neighbours dies by over-population.
4. Any dead cell with exactly three live neighbours becomes a live cell by reproduction.

A living cecll is denoted by a # and a dead cell is denoted by a -


FLOW OF THE PROGRAM:

The user will first enter the number of living cells
The program will the ask for the cordinates of the living cell
The game takes place in a 2 dimensional plane of 20x20 cells
The program then applies the rules mentioned above and determines the next state of the living cells
Death or reproduction or continuation to stay alive depends upon the rules mentioned


FUCTIONS AND THEIR FUNCTIONALITY

1) void clearScreen(void)
	This functions uses system calls to clear the console. This function ensures that
the screen is cleared at every iteration for better visualisation of progress of the game.
This allows the screen to be cleared on both OS windows and linux.


2) void DisplayEarth(bool flatEarth[][])
	This function is a simple method to display the 2 dimensional plane where the simulation
is being executed. Uses nested for loops to access all the elements in the plane.


3) void CopyEarth(bool flatearth[][], bool earthCopy[][])
	This function creates a copy of the current state for comparison to determin the
next state of the cells. This function is called within IsAlive function to perform its 
purpose where a temporary copy is made for checking the neighbours of a certain cell.

4) void IsAlive(bool flatearth[][])
	This function determines the next state of the cells. Makes use of a temporary copy
of the current plane and determines the number of neighbours alive by use of for loops.
The number of neighbours alive determines the next state in light of the rules.




SOME OTHER FUNCTIONS USED:

usleep(1000000)
	This functions pauses the screen for the micro seconds entered. usleep(1000000) means
the screen will be paused for 1 second,like wise usleep(800000) means the screen will be paused
for 0.8 seconds. This is system call to pause the running terminal for the entered value of 
micro seconds.	


Resources used:
https://stackoverflow.com/questions/4184468/sleep-for-milliseconds

