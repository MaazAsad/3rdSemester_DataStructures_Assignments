//============================================================================
// Name        : GameOfLife.cpp
// Author      : MaazAsad
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in ++c, Ansi-style
//============================================================================

#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <string>

using namespace std;

const int _earthSize_ = 20;
void clearScreen(void) {
    //function to clear screen
	//internet resources used to make this function
    #if defined(_WIN32) || defined(WIN32) || defined(__MINGW32__) || defined(__BORLANDC__)//different ways to declare running OS
        #define OS_WIN
    #endif

    #ifdef OS_WIN
        system("CLS");
    #endif

    #if defined(linux) || defined(__CYGWIN__)//for linux
        system("clear");
    #endif
}

void DisplayEarth(bool flatEarth[_earthSize_+1][_earthSize_+1]){
    for(int row = 1; row < _earthSize_; ++row){
        for(int col = 1; col < _earthSize_; ++col){
            if(flatEarth[row][col] == true){
                cout << " # ";
            }
            else{
                cout << " - ";
            }
            if(col == _earthSize_-1){
                cout << endl;
            }
        }
    }
}

void CopyEarth (bool flatEarth[_earthSize_+1][_earthSize_+1], bool earthCopy[_earthSize_+1][_earthSize_+1]){
    for(int a =0; a < _earthSize_; ++a){
        for(int b = 0; b < _earthSize_; ++b){
                earthCopy[a][b] = flatEarth[a][b];
        }
    }
}

void IsAlive(bool flatEarth[_earthSize_+1][_earthSize_+1]){
    bool earthCopy[_earthSize_+1][_earthSize_+1] = {};
    CopyEarth(flatEarth, earthCopy);

    for(int a = 1; a < _earthSize_; ++a){
        for(int b = 1; b < _earthSize_; ++b){
            int _n_alive = 0;
            for(int c = -1; c < 2; ++c){
                for(int d = -1; d < 2; ++d){
                    if(!(c == 0 && d == 0)){
                        if(earthCopy[a+c][b+d]){
                        	++_n_alive;
                        }
                    }
                }
            }
            if(_n_alive < 2){
                flatEarth[a][b] = 0;
            }
            else if(_n_alive == 3){
                flatEarth[a][b] = 1;
            }
            else if(_n_alive > 3){
                flatEarth[a][b] = 0;
            }
        }
    }
}


int main(){

    system( "color A" ); // system directive to change color of console
    bool flatEarth[_earthSize_+1][_earthSize_+1] = {}; // initializing 2d array
    int x,y;
    string nc;
    string start;
	cout << "Welcome to GAME OF LIFE" << endl;
	cout << "Devised by the British mathematician John Horton Conway in 1970.\n" << endl;
    cout << "Rules:\n";
    cout << "The universe of the Game of life is an infinite two-dimensional plane of square cells,\n";
    cout << "each of which is in one of two possible states, dead or alive." << endl;
    cout << "Cells interact with their eight neighbours (horizontally, vertically, or diagonally adjacent).\n";
    cout << "At each iteration, the following changes occur:";
    cout << "\n 1. Any live cell with fewer than two live neighbours dies by under-population.";
    cout << "\n 2. Any live cell with two or three live neighbours lives on to the next generation.";
    cout << "\n 3. Any live cell with more than three live neighbours dies by over-population.";
    cout << "\n 4. Any dead cell with exactly three live neighbours becomes a live cell by reproduction.\n";
    cout << "#  living cell" << endl;
    cout << "-  dead cell" << endl;
    cout << endl;

    //take user input
    cout << "Enter the number of alive members: ";
    cin >> nc;
    cout << endl;
	for(int i=0;i<stoi(nc);++i){
		cout << "Enter the coordinates of cell " << i+1 << " : ";
		cin >> x >> y;
		flatEarth[x][y] = 1;
		DisplayEarth(flatEarth);
	  }


    cout << "Start the game?(Y/N)"<<endl;
    DisplayEarth(flatEarth);
    cin >> start;
    if( start == "y" || start == "Y" ){
        while (true){
            DisplayEarth(flatEarth);
            IsAlive(flatEarth);
            usleep(1000000);
            clearScreen();
        }
      }

     return 0;

}

