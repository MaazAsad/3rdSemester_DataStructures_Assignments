#include<iostream>
#include<fstream>
#include "../Assignment#3/TIRE.h"

int main(){
    ifstream myfile;
    myfile.open("dictionary.txt");

    string temp,x;
    temp = "";

    while(!myfile.eof()){
        getline(myfile,x);
        if(x[0] == '-' && x[1] == '-'){
            //is a meaning
            
        }
        else if(x[0] == '-' && x[1] != '-'){
            //is a word
        }
        else{
            //is a synonym
        }

    }
        

    return 0;
}