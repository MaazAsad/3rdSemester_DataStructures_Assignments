#include "./TIRE.h"
#include <cstdlib>
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <iterator>

using namespace std;


int main(){

	cout << "Testing file open" << endl;
	ifstream is("..\\trie\\dictionary.txt",std::ifstream::in);
		
	if (!is.is_open()) {
		cout << (false) << endl;
	} 
	else {
		cout << (true)<<endl;
	}
	is.close();	


	TRIE test;
	test.CreateDictionary("..\\trie\\dictionary.txt");
	
	string data;
	
	string dict_words[] = { "piper", "picked", "peck", "pecked", "pickled", "peppers", "silent", "listen", "zooid", "zoetrope",
						"hapten", "theatrical", "ownership", "tension", "poetic", "preventable", "hopeless" };

	int num_words = sizeof(dict_words) / sizeof(string);
	sort(dict_words, dict_words + num_words);

	vector<string> ListOfWords = test.OutputAscending();
	
	cout << "Size test" << endl;
	cout << ListOfWords.size()  << ' ' << num_words << endl;

	for (int i = 0; i < num_words; ++i) {
		cout << (ListOfWords[i] == dict_words[i]);
	}

	reverse(dict_words, dict_words + num_words);

	ListOfWords = test.OutputDescending();
	cout << (ListOfWords.size() == num_words);

	cout << endl << "Word test" << endl;
	for (int i = 0; i < num_words; ++i) {
		cout << (ListOfWords[i] == dict_words[i]) << endl;
	}



	cout << endl << "word finder test" << endl;
	cout << (1 ==  test.FindWord("peck")) << endl;
	cout <<	(1 == test.FindWord("piper"))<<endl;
	cout <<	(0 == test.FindWord("apple")) << endl;
	cout << (0 ==test.FindWord("pip")) << endl;



	// cout << "Synonyms test" << endl;
	// vector<string> ListOfSynonyms = test.FindSynonyms("peck");

	// string expected[] = { "strike", "beak", "pick" };

	// int i=0
	// for (vector<string>::iterator it = ListOfSynonyms.begin()  ; it != ListOfSynonyms.end(); ++it, ++i){
   	//  	cout << (*it == expected[i]) << endl;
	// }




	cout << endl << "Meaning test" << endl;
	data = test.FindMeaning("peck");
	cout << (0 == data.compare("a stroke or bite by a bird with its beak.")) << endl;
	data = test.FindMeaning("piper");
	cout << (0 == data.compare("a person who plays a pipe, especially an itinerant musician.")) << endl;


	// TEST(testTRIE, FindPrefix)
	// {
	// 	TRIE test;
	//     test.CreateDictionary("..\\trie\\dictionary.txt");

	// 	vector<string> ListOfWords = test.OutputPrefix("pick");

	// 	string expected[] = { "picked", "pickled" };

	// 	cout << (ListOfWords.Size() == 2);
	// 	for (string& ex : expected) {
	// 		cout << (ListOfWords.find(ex) != -1);
	// 	}

	// }


	// TEST(testTRIE, FindSmallerGreaterEqual)
	// {
	// 	TRIE test;
	//     test.CreateDictionary("..\\trie\\dictionary.txt");

	// 	{
	// 		vector<string> ListOfWords = test.OutputSmaller(6);

	// 		string expected[] = { "piper", "peck",  "zooid" };

	// 		cout << (ListOfWords.Size() == 3);
	// 		for (string& ex : expected) {
	// 			cout << (ListOfWords.find(ex) != -1);
	// 		}
	// 	}
		
	// 	{
	// 		vector<string> ListOfWords = test.OutputSE(5);

	// 		string expected[] = { "piper", "peck",  "zooid" };

	// 		cout << (ListOfWords.Size() == 3);
	// 		for (string& ex : expected) {
	// 			cout << (ListOfWords.find(ex) != -1);
	// 		}
	// 	}

	// 	{
	// 		vector<string> ListOfWords = test.OutputGreater(6);

	// 		string expected[] = { "pickled", "peppers",  "zoetrope", "theatrical", "ownership", "tension", "preventable", "hopeless" };

	// 		cout << (ListOfWords.Size() == 8);

	// 		for (string& ex : expected) {
	// 			cout << (ListOfWords.find(ex) != -1);
	// 		}
	// 	}

	// }

	// TEST(testTRIE, FindAnagrams)
	// {
	// 	TRIE test;
	//     test.CreateDictionary("..\\trie\\dictionary.txt");

	// 	vector<string> ListOfWords = test.OutputAnagrams("listen");

	// 	cout << (ListOfWords.Size() == 1);
	// 	string data;
	// 	data = ListOfWords[0];
	// 	EXPECT_EQ(0, data.compare("silent"));
	// }


	// TEST(testTRIE, FindSuffix)
	// {

	// 	TRIE test;
	//     test.CreateDictionary("..\\trie\\dictionary.txt");
	// 	vector<string> ListOfWords = test.OutputSuffix("cked");

	// 	string expected[] = { "pecked", "picked" };

	// 	cout << (ListOfWords.Size() == 2);

	// 	for (string& ex : expected) {
	// 		cout << (ListOfWords.find(ex) != -1);
	// 	}
	// }


	// TEST(testTRIE, CompleteString)
	// {

	// 	string dict_words[] = { "piper", "picked", "peck", "pecked", "pickled", "peppers", "silent", "listen", "zooid", "zoetrope",
	// 					"hapten", "theatrical", "ownership", "tension", "poetic", "preventable", "hopeless" };

	// 	TRIE test;
	// 	test.CreateDictionary("..\\trie\\dictionary.txt");
		
	// 	{
	// 		vector<string> ListOfWords = test.CompleteString("pip");
	// 		string expected[] = { "piper" };

	// 		cout << (ListOfWords.Size() == 1);

	// 		for (string& ex : expected) {
	// 			cout << (ListOfWords.find(ex) != -1);
	// 		}
	// 	}

	// 	{
	// 		vector<string> ListOfWords = test.CompleteString("eck");
	// 		string expected[] = { "pecked", "peck" };

	// 		cout << (ListOfWords.Size() == 2);

	// 		for (string& ex : expected) {
	// 			cout << (ListOfWords.find(ex) != -1);
	// 		}
	// 	}

	// }

	// TEST(testTRIE, SpellChecker)
	// {
	// 	TRIE test;
	// 	test.CreateDictionary("..\\trie\\dictionary.txt");

	// 	vector<string> ListOfWords = test.SpellChecker("packed");
	// 	cout << (ListOfWords.Size() == 1);
	// 	EXPECT_EQ(0, ListOfWords[0].compare("pecked"));

	// 	ListOfWords = test.SpellChecker("silnt");
	// 	cout << (ListOfWords.Size() == 1);
	// 	EXPECT_EQ(0, ListOfWords[0].compare("silent"));
	// }

	// SpellChecker
}