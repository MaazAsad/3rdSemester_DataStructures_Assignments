#ifndef TIRE_H
#define TRIE_H
#include<iostream>
#include<string>
#include<fstream>
#include<vector>
#include<time.h>
#include<algorithm>
using namespace std;

//vector stl have been used 
//didn't had enough time to implement the Vector class myself
//life is a lemon

class TRIE{

    class Node{
        public:
            string meaning;
            vector <string> synonyms;
            Node* alphabetArray[26];
            long key;

            Node() {
            for (int i = 0; i < 26; i++) {
                alphabetArray[i] = nullptr;
            }
            key = time(NULL);
            meaning = "";

        }

        Node(int index) {
            for (int i = 0; i < 26; i++) {
                if (i == index)
                    alphabetArray[i] = new Node;
                else
                    alphabetArray[i] = nullptr;
            }

            meaning = "";
            key = time(NULL);
        }

        Node(string Meaning, vector <string> Synonyms) {
            for (int i = 0; i < 26; i++) {
                alphabetArray[i] = nullptr;
            }
            meaning = Meaning;
            synonyms = Synonyms;
            key = time(NULL);
        }

        bool clearProperties() {
            meaning = "";
            synonyms.clear();
            for (int i = 0; i < 26; i++) {
                if (alphabetArray[i] != nullptr)
                    return false;
            }
            return true;
        }

        bool isCursorWord() {
            return meaning != "";
        }

        void setCharacter(char index) {
            if (index <= 'Z' && index >= 'A') {
                index -= 'A';
            }
            else if (index <= 'z' && index >= 'a') {
                index -= 'a';
            }
            else
                throw invalid_argument("Index is less than or greater than the alphabet!");


            alphabetArray[(int)index] = new Node;

        }

        Node*& moveToAlphabet(char index) {
            if (index <= 'Z' && index >= 'A') {
                index -= 'A';
            }
            else if (index <= 'z' && index >= 'a') {
                index -= 'a';
            }
            else if (index > 25 || index < 0)
                throw invalid_argument("Index is less than or greater than the alphabet!");
           
            if (alphabetArray[(int)index] == nullptr)
                throw logic_error("Cannot move as the Node is nullptr.");
            return alphabetArray[(int)index];
        }

        bool isAlphabetNull(char index) {
            if (index <= 'Z' && index >= 'A') {
                index -= 'A';
            }
            else if (index <= 'z' && index >= 'a') {
                index -= 'a';
            }
            else if (index > 25 || index < 0)
                throw invalid_argument("Index is less than or greater than the alphabet!");

            return alphabetArray[(int)index] == nullptr;
        }

        void setMeaning(string Meaning) {
            this->meaning = Meaning;

        }

        void setKey() {
            key = time(NULL);
        }

        void addSynonym(string synonym) {
            synonyms.push_back(synonym);

        }


        bool isNull() {
            return meaning == "";
        }


        ~Node() {
            for (int i = 0; i < 26; i++) {
                if (alphabetArray[i] != nullptr)
                    delete alphabetArray[i];
            }
	    }
    };

    Node* root;
    int size;

    public:
    TRIE(){
        root = NULL;
		size = 1;
    }


    void CreateDictionary(string filedir){
       root = new Node;
		
		ifstream dicFile(filedir);
		if (!dicFile.good()) {
			throw invalid_argument("File couldn't be found.");
		}
		else if (dicFile.eof())
			throw invalid_argument("File is empty!");

		Node* cursor = root;
		char c = dicFile.get();
		while (!dicFile.eof()) {
			if (c == '-') {
				c = dicFile.get();
				if (c == '-') {
					++size;
					string meaning;
					getline(dicFile, meaning, '\n');
					cursor->setMeaning(meaning);
				}
				else {
					cursor = root;
					while (c != '\n') {
						if (cursor->isAlphabetNull(c)) {							
							cursor->setCharacter(c);
						}
						cursor = cursor->moveToAlphabet(c);
						c = dicFile.get();
					}
				}
			}
			else if (c != '-') {
				string synonym = "";
				synonym += c;
				string getSynonym;
				getline(dicFile, getSynonym, '\n');
				synonym += getSynonym;
				cursor->addSynonym(synonym);
			}
			c = dicFile.get();
		}
		dicFile.close();
    }


    vector<string> OutputAscending(){
        if (isEmpty())
			throw invalid_argument("The Trie is empty!");

		vector<string>returnTo;
		getWordsRecursively(root, returnTo);
		return returnTo;
    }

    vector<string> OutputDescending(){
        vector<string> output = OutputAscending();
		reverse(output.begin(), output.end());
		return output;
    }

    bool FindWord(string key){
        Node* cursor = root;

		for (int i = 0; i < key.size(); i++) {
			try {
				cursor = cursor->moveToAlphabet(key[i]);
			}
			catch (invalid_argument& e) {
				cout << "Caught an error! " << e.what() << endl;
				return false;
			}
			catch (logic_error& e) {
				string error = e.what();
				error += " The word could not be found.";
				return false;
			}
		}

		
		if (cursor->meaning == "") {
			
			return false;
		}
		return true;
    }

    vector<string> FindSynonyms(string key){
        Node* cursor = root;
		for (int i = 0; i < key.size(); i++) {
			try {
				cursor = cursor->moveToAlphabet(key[i]);
			}
			catch (invalid_argument& e) {
				throw invalid_argument(e.what());
			}
			catch (logic_error& e) {
				string error = e.what();
				error += " The word could not be found.";
				throw invalid_argument(error);
			}
		}
		return cursor->synonyms;
    }


    string FindMeaning(string word){
        Node* cursor = root;
		for (int i = 0; i < word.size(); i++) {
			try {
				cursor = cursor->moveToAlphabet(word[i]);
			}
			catch (invalid_argument& e) {
				throw invalid_argument(e.what());
			}
			catch (logic_error& e) {
				string error = e.what();
				error += " The word could not be found.";
				throw invalid_argument (error);
			}
		}
		return cursor->meaning;
    }

    vector <string> OutputAnagrams(string theWord) {
		if (isEmpty()) {
			throw invalid_argument("The trie is empty!");
		}
		vector <string> returnTo;
		OutputAnagramsRecursion(root, returnTo, theWord);
		auto it = std::find(returnTo.begin(), returnTo.end(), theWord);
	
		if (it != returnTo.end()) {
			returnTo.erase(it);
		}
		return returnTo;
	}


    vector <string> OutputAnagramsRecursion(Node* cursor, vector<string>& returnTo, string theWord, string result = "") {
		if (cursor->isCursorWord()) {
			if (result != theWord) {
				returnTo.push_back(result);
			}
		}
		for (int m = 0; m < 26; m++) {
			int index = theWord.find(m + 97);

			char letter;
			if (index != -1) {
				if (!cursor->isAlphabetNull(m)) {
					letter = m + 97;
					string result;
					for (size_t i = 0; i < theWord.size(); i++)
					{
						char currentChar = theWord[i];
						if (i != index) {
							result += currentChar;
						}
					}
					theWord = result;

					OutputAnagramsRecursion(cursor->moveToAlphabet(m), returnTo, theWord, result += letter);
					theWord += letter;
					result.erase(result.end() - 1);
				}
			}

		}
		return returnTo;
	}


	void getWordsRecursively(Node * cursor, vector<string> &returnTo, string attachIt="", string result="") {

		if (cursor->isCursorWord()) {

			string returnThis = attachIt + result;
			
			returnTo.push_back(returnThis);
		}

		for (int m = 0; m < 26; m++) {
			if (!cursor->isAlphabetNull(m)) {
				char letter = m + 97;
				getWordsRecursively(cursor->moveToAlphabet(m), returnTo, attachIt, result += letter);
				result.erase(result.end() - 1); 
			}
		}
		
		return;
	}

    
    string* OutputPrefix(string prefix){
        Node* cursor = root;
		for (int i = 0; i < prefix.size(); i++) {
			try {
				cursor = cursor->moveToAlphabet(prefix[i]);
			}
			catch (invalid_argument& e) {
				throw invalid_argument(e.what());
			}
			catch (logic_error& e) {
				string error = e.what();
				error += " The word could not be found.";
				throw invalid_argument(error);
			}
		}
		vector<string> returnTo;
        string x;
		getWordsRecursively(cursor, returnTo, prefix,x);
		return &x;
    }
    
    string* OutputSuffix(string key){

    }

    vector<string> OutputSmaller(int num){
        vector<string> temp;
		vector<string> returnTo;
		Node* cursor = root;
		getWordsRecursively(cursor, returnTo);

		for(int i = 0; i< returnTo.size(); ++i){
			if(returnTo[i].length()<= num)
				temp.push_back(returnTo[i]);
		}

        return temp;
    }

    vector<string> OutputGreater(int num){
        vector<string> temp;
		vector<string> returnTo;
		Node* cursor = root;
		getWordsRecursively(cursor, returnTo);

		for(int i = 0; i< returnTo.size(); ++i){
			if(returnTo[i].length() >= num)
				temp.push_back(returnTo[i]);
		}

        return temp;
    }

    vector<string> CompleteString(string key){
        vector<string> temp;

        return temp;
    }

    bool SpellChecker(string key){
        return false;
    }

    vector< string> OutputSE(int length){
        vector<string> temp;

        return temp;
    }

    int Size(){
        return size;
    }



    bool deleteWord(string word) {
		Node* cursor = root;
		for (int i = 0; i < word.size(); i++) {
			try {
				cursor = cursor->moveToAlphabet(word[i]);
			}
			catch (invalid_argument& e) {
				throw invalid_argument(e.what());
			}
			catch (logic_error& e) {
				string error = e.what();
				error += " The word could not be found.";
				throw invalid_argument(error);
			}
		}
		if (cursor->clearProperties())
			delete cursor;
		return true;
	}


	Node*& insertTemporary(string newWord) {
		Node* cursor = root;
		for (int i = 0; i < newWord.size(); i++) {
			if (cursor->isAlphabetNull(newWord[i])) {

				try {
					cursor->setCharacter(newWord[i]);
				}
				catch (invalid_argument& e) {
					cout << "Error caught! " << e.what() << endl;
				}
			}

			
			cursor = cursor->moveToAlphabet(newWord[i]);
		}

		return cursor;
	}


	bool isEmpty() {
		return root == nullptr;
	}

	void clear() {

	}

	virtual ~TRIE() {

	}

};


#endif